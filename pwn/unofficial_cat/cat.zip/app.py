from flask import Flask, request, render_template
import subprocess
import os
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = './uploads'
ALLOWED_EXTENSIONS = {'txt'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET", "POST"])
def index():
    output = ""
    if request.method == "POST":
        uploaded_file = request.files.get("file")
        if uploaded_file and allowed_file(uploaded_file.filename):
            filename = secure_filename(uploaded_file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            uploaded_file.save(filepath)

            try:
                result = subprocess.run(
                    ["./cat", filepath],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    timeout=3,
                    check=False,
                )

                output = result.stdout.decode('utf-8', errors='replace') or result.stderr.decode('utf-8', errors='replace')
            except Exception as e:
                output = f"Error: {str(e)}"
        else:
            output = "Only .txt files are allowed."

    return render_template("index.html", output=output)
