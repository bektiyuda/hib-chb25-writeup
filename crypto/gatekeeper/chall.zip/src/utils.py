import re
import secrets
import string

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD_LENGTH = 64
USERNAME_REGEX = r'^[A-Za-z0-9]+$'
USERNAME_MIN_LENGTH = 8
USERNAME_MAX_LENGTH = 64


def generate_random_password(length: int = ADMIN_PASSWORD_LENGTH) -> str:
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


def validate_username(username: string) -> tuple[bool, str]:
    if not re.fullmatch(USERNAME_REGEX, username):
        return False, 'Username must be alphanumeric (letters and numbers only).'
    if len(username) < USERNAME_MIN_LENGTH:
        return False, f'Username must be at least {USERNAME_MIN_LENGTH} characters.'
    if len(username) > USERNAME_MAX_LENGTH:
        return False, f'Username must be at most {USERNAME_MAX_LENGTH} characters.'
    return True, None
