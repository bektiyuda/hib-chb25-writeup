import os
from base64 import urlsafe_b64decode


class ConfigError(Exception):
    pass


class Config:
    SECRET_KEY = urlsafe_b64decode(os.environ.get('SECRET_KEY'))
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')
    FLAG = os.environ.get('FLAG')
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    @classmethod
    def validate(cls):
        missing = []
        if not cls.SECRET_KEY:
            missing.append('SECRET_KEY')
        if not cls.SQLALCHEMY_DATABASE_URI:
            missing.append('DATABASE_URL')
        if not cls.FLAG:
            missing.append('FLAG')
        if missing:
            raise ConfigError(
                f"Missing required environment variable(s): {', '.join(missing)}"
            )


class ProductionConfig(Config):
    DEBUG = False


class DevelopmentConfig(Config):
    DEBUG = True
