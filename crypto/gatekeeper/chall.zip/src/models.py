from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user = db.Column(db.String(64), unique=True, nullable=False)
    role = db.Column(db.String(32), nullable=False, default='user')
    password = db.Column(db.String(128), nullable=False)

    def __repr__(self):
        return f'<User {self.user} ({self.role})>'
