import base64


def process_bytes(data: bytes, key: bytes) -> bytes:
    return bytes([b ^ key[i % len(key)] for i, b in enumerate(data)])


def create_token(identifier: str, secret: bytes) -> str:
    data = pad(identifier.encode())

    processed = process_bytes(data, secret)
    return base64.urlsafe_b64encode(processed).decode()


def validate_token(token: str, secret: bytes) -> str:
    try:
        processed = base64.urlsafe_b64decode(token)
        identifier = unpad(process_bytes(processed, secret)).decode()
        return identifier
    except Exception:
        return None


def pad(data: bytes, block_size: int = 64) -> bytes:
    if block_size < 1 or block_size > 255:
        raise ValueError('block_size must be between 1 and 255')
    pad_len = block_size - (len(data) % block_size)
    return data + bytes([pad_len] * pad_len)


def unpad(padded_data: bytes, block_size: int = 64) -> bytes:
    if not padded_data or len(padded_data) % block_size != 0:
        raise ValueError('Input data is not padded or block_size is incorrect')
    pad_len = padded_data[-1]
    if pad_len < 1 or pad_len > block_size:
        raise ValueError('Invalid padding length')
    if padded_data[-pad_len:] != bytes([pad_len] * pad_len):
        raise ValueError('Invalid padding bytes')
    return padded_data[:-pad_len]
