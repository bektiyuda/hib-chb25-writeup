from flask import (
    Flask, render_template, request, redirect, url_for, flash, make_response, current_app
)
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from .config import DevelopmentConfig
from .models import db, User
from .services import create_token, validate_token
from .utils import (
    ADMIN_USERNAME, generate_random_password, validate_username
)


def get_current_user():
    token = request.cookies.get('auth_token')
    if not token:
        return None
    secret = current_app.config['SECRET_KEY']
    identifier = validate_token(token, secret)
    if not identifier:
        return None
    return User.query.filter_by(user=identifier).first()


def create_app():
    app = Flask(__name__, template_folder='templates')
    app.config.from_object(DevelopmentConfig)
    db.init_app(app)

    limiter = Limiter(
        get_remote_address,
        app=app,
        default_limits=['10 per minute']
    )

    with app.app_context():
        db.create_all()
        admin_user = User.query.filter_by(user=ADMIN_USERNAME).first()
        if not admin_user:
            admin_password = generate_random_password()
            admin_user = User(user=ADMIN_USERNAME, password=admin_password, role='admin')
            db.session.add(admin_user)
            db.session.commit()
            print(f'[INFO] Created admin user: {ADMIN_USERNAME} / {admin_password}')

    @app.route('/')
    def index():
        return render_template('index.html', user=get_current_user())

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            role = 'user'

            if not username or not password:
                flash('Username and password required.')
                return redirect(url_for('register'))

            is_valid, error = validate_username(username)
            if not is_valid:
                flash(error)
                return redirect(url_for('register'))

            if User.query.filter_by(user=username).first():
                flash('Username already exists.')
                return redirect(url_for('register'))

            user = User(user=username, password=password, role=role)
            db.session.add(user)
            db.session.commit()
            flash('Registration successful. Please log in.')
            return redirect(url_for('login'))

        return render_template('register.html', user=get_current_user())

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')

            user = User.query.filter_by(user=username).first()
            if user and user.password == password:
                secret = current_app.config['SECRET_KEY']
                token = create_token(user.user, secret)
                resp = make_response(redirect(url_for('dashboard')))
                resp.set_cookie('auth_token', token)
                flash('Logged in successfully.')
                return resp
            else:
                flash('Invalid username or password.')

        return render_template('login.html', user=get_current_user())

    @app.route('/logout')
    def logout():
        resp = make_response(redirect(url_for('index')))
        resp.delete_cookie('auth_token')
        flash('Logged out.')
        return resp

    @app.route('/dashboard')
    def dashboard():
        user = get_current_user()
        if not user:
            flash('Please log in first.')
            return redirect(url_for('login'))

        secret = current_app.config['SECRET_KEY']
        token = create_token(user.user, secret)
        flag = current_app.config.get('FLAG') if user.role == 'admin' else None

        return render_template('dashboard.html', user=user, token=token, flag=flag)

    return app
