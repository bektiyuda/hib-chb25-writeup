

if __name__ == '__main__':
    from dotenv import load_dotenv
    load_dotenv()

    from src.app import create_app
    create_app = create_app()
    create_app.run(debug=True)
else:
    from src.app import create_app
    gunicorn_app = create_app()
