import dotenv
import os
import typing as t
from hashlib import sha1


def unlock_dessert(username: bytes, password: bytes) -> str:
    if username == password:
        raise PermissionError()

    if sha1(username).digest() != sha1(password).digest():
        raise PermissionError()

    return os.getenv('FLAG', 'FLAG_NOT_SET')


def main():
    dotenv.load_dotenv()
    print('Get a chance for free dessert!')
    username = bytes.fromhex(input('Username (hex): '))
    password = bytes.fromhex(input('Password (hex): '))

    try:
        dessert = unlock_dessert(username, password)
        print('Welcome! Here\'s your dessert:', dessert)
    except PermissionError:
        print('No dessert for you :(')


if __name__ == '__main__':
    main()
