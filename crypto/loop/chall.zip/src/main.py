from config import Config
from Crypto.PublicKey import RSA
from Crypto.Util.number import long_to_bytes, bytes_to_long


def main():
    config = Config()

    key = RSA.generate(bits=config.BIT_SIZE)
    public_key = key.publickey()

    encrypted_flag = b''

    for character in config.FLAG:
        salted = (character + config.generate_salt()).encode()
        encrypted = public_key._encrypt(bytes_to_long(salted))  # type: ignore
        encrypted_flag += long_to_bytes(encrypted)

    with open('out/public_key.pem', 'wb') as f:
        f.write(public_key.export_key())

    with open('out/encrypted_flag.bin', 'wb') as f:
        f.write(encrypted_flag)


if __name__ == '__main__':
    main()
