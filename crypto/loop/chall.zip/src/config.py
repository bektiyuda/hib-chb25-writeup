import os
from dotenv import load_dotenv


class Config:
    def __init__(self):
        load_dotenv()
        if 'FLAG' not in os.environ:
            raise ValueError('Environment variable \'FLAG\' is not set.')

        self.BIT_SIZE = 2048
        self.PAD_SIZE = 3
        self.FLAG = os.getenv('FLAG', '')
        self.state = 0

    def generate_salt(self) -> str:
        self.state += 1
        return f'_SALTED_{self.state:02d}'
