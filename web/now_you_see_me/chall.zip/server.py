import os
import jwt
from flask import Flask, request, jsonify
from dotenv import load_dotenv

load_dotenv()
JWT_SECRET = os.getenv('JWT_SECRET').encode()

app = Flask(__name__)

# Simple user "database"
users = {}

@app.errorhandler(Exception)
def handle_exception(e):
    print(f"Unhandled Exception: {str(e)}")
    return jsonify({"error": "Internal Server Error"}), 500

@app.errorhandler(404)
def handle_404(e):
    return jsonify({"error": "Not Found"}), 404

@app.route("/api/register", methods=["POST"])
def register():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "Missing username or password"}), 400

    if username in users:
        return jsonify({"error": "User already exists"}), 409

    users[username] = {"password": password, "is_admin": False}
    return jsonify({"message": "User registered successfully"})

@app.route("/api/login", methods=["POST"])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    user = users.get(username)
    if not user or user["password"] != password:
        return jsonify({"error": "Invalid credentials"}), 401

    payload = {"username": username, "is_admin": user.get("is_admin", False)}
    token = jwt.encode(payload, JWT_SECRET, algorithm='HS256')
    return jsonify({"token": token})

@app.route("/api/admin", methods=["GET"])
def admin():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return jsonify({"error": "Missing or invalid token"}), 401

    token = auth[len("Bearer "):]
    payload = jwt.decode(token, JWT_SECRET, algorithm='HS256')

    if not payload.get("is_admin"):
        return jsonify({"error": "Access denied, admin only"}), 403

    return jsonify({"flag": os.getenv("FLAG", "HIB{default_flag}")})

if __name__ == "__main__":
    app.run(debug=False, port=5000, host='0.0.0.0')