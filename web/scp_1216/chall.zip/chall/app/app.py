from flask import Flask, request, jsonify, render_template, redirect, session, abort, Response
from flask_sqlalchemy import SQLAlchemy
from urllib.parse import urlparse
import requests
import secrets
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils import hash_password, check_password

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

SECRET_PIN = '???-???-???-???' # Placeholder for the secret pin

from .models import create_models, ThreatLevel
User, SCP = create_models(db)

with app.app_context():
    db.create_all()
    
    # Add sample data if database is empty
    if SCP.query.count() == 0:
        sample_scps = [
            SCP(name='SCP-173', description='Concrete sculpture that moves when unobserved', 
                containment='Keep under constant observation', threat_level=ThreatLevel.HIGH),

            SCP(name='SCP-096', description='Pale humanoid that becomes hostile when viewed', 
                containment='Avoid viewing at all costs', threat_level=ThreatLevel.CRITICAL),

            SCP(name='SCP-999', description='Friendly orange blob', 
                containment='Allow free roaming', threat_level=ThreatLevel.LOW),

            SCP(name='SCP-682', description='Highly intelligent and extremely hostile reptile', 
                containment='Keep submerged in acid; containment upgrades ongoing', threat_level=ThreatLevel.CRITICAL),

            SCP(name='SCP-049', description='Humanoid resembling a plague doctor', 
                containment='Held in secure cell; conversations allowed under supervision', threat_level=ThreatLevel.MODERATE),

            SCP(name='SCP-106', description='Decaying humanoid that can pass through walls', 
                containment='Lure back into containment using live bait; secure within sealed chamber', threat_level=ThreatLevel.CRITICAL),

            SCP(name='SCP-914', description='Clockwork device that can refine or degrade objects', 
                containment='No testing without prior approval from Level 2 personnel', threat_level=ThreatLevel.MODERATE),

            SCP(name='SCP-087', description='Endless stairwell that induces paranoia and hallucinations', 
                containment='Keep entrance locked and sealed', threat_level=ThreatLevel.HIGH),

            SCP(name='SCP-131', description='Two small eyeball-shaped creatures', 
                containment='No special containment needed; keep away from SCP-173', threat_level=ThreatLevel.LOW),

            SCP(name='SCP-105', description='Female human with anomalous photographic connection', 
                containment='Voluntary containment; subject cooperates with Foundation', threat_level=ThreatLevel.MODERATE),
        ]
        
        for scp in sample_scps:
            db.session.add(scp)
        db.session.commit()
        print("Sample SCP data added to database")



@app.route('/')
def index():
    if 'user_id' not in session:
        abort(403)
    
    user = User.query.get(session['user_id'])
    scps = SCP.query.all()
    
    if user.is_admin:
        return render_template('index.html', scps=scps, admin=True)
    
    return render_template('index.html', scps=scps, admin=False)

@app.route('/admin/fetch-scp', methods=['GET', 'POST'])
def fetch_scp():
    if 'user_id' not in session:
        abort(403)

    user = User.query.get(session['user_id'])
    if not user.is_admin:
        abort(403)

    res = None

    if request.method == 'POST':
        data = request.get_json()
        url = data.get('url')
        
        parsed_url = urlparse(url)
        
        if parsed_url.scheme not in ['http', 'https']:
            return jsonify({'error': 'Invalid URL scheme'}), 400
        elif parsed_url.hostname != 'scp-anomaly.com':
            return jsonify({'error': 'Invalid hostname'}), 400
        else:
            try:
                resp = requests.get(url, timeout=5)
                res = resp.text
            except Exception as e:
                res = f"Error fetching SCP data: {str(e)}"

    return render_template('fetch_scp.html', result=res)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        data = request.get_json()
        data['password'] = hash_password(data['password'])
        
        user = User(**data)
        db.session.add(user)
        db.session.commit()
        
        return redirect('/login')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.get_json()

        username = data.get('username')
        password = data.get('password')

        user = User.query.filter_by(username=username).first()

        if user and check_password(user.password, password):
            session['user_id'] = user.id
            return jsonify({'success': True})
        else:
            return jsonify({'error': 'Invalid username or password'}), 401
    return render_template('login.html')

@app.route('/vault')
def secret_page():
    if request.remote_addr != '127.0.0.1':
        abort(403)
    
    password = request.args.get('password')
    
    if not password:
        return render_template('vault_page.html', text='You dont deserve this secret yet!')

    if password != 'p4ssw0rdnya_H1b_Jay4_J4ya':
        return render_template('vault_page.html', text='You dont deserve this secret yet!')

    try:
        with open('secret.txt', 'r') as f:
            res = f.read()
        return render_template('vault_page.html', text=res)
    except Exception as e:
        return render_template('vault_page.html', text=f'Error')
    
@app.route('/secret-console', methods=['GET', 'POST'])
def console():
    if 'user_id' not in session:
        abort(403)
    
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        abort(403)
    
    if not session.get('console_access'):
        if request.method == 'POST':
            data = request.get_json()
            
            if 'pin' in data:
                pin = data.get('pin')
                if pin == SECRET_PIN.replace("-", ""):
                    session['console_access'] = True
                    return jsonify({'pin_verified': True})
                else:
                    return jsonify({'error': 'Invalid PIN'}), 401
            else:
                return jsonify({'error': 'PIN required'}), 403
        
        return render_template('console_pin.html')
    
    if request.method == 'POST':
        try:
            data = request.get_json()
            code = data.get('code', '')
            
            import re
            import subprocess
            
            dangerous_patterns = [
                'subprocess', 'system', 'exec', 'eval', '__import__',
                'rm ', 'mv ', 'cp ', 'chmod', 'chown', 'kill', 'sudo',
                'wget', 'curl', 'nc ', 'netcat', 'ssh', 'ftp', 'python',
                'bash', 'sh ', '/bin/', 'proc', 'dev'
            ]
            
            code_lower = code.lower()
            for pattern in dangerous_patterns:
                if pattern in code_lower:
                    return jsonify({'error': 'Restricted operation detected'}), 403
            
            if 'os.popen' in code:
                popen_match = re.search(r"os\.popen\(['\"]([^'\"]+)['\"]\)", code)
                if popen_match:
                    command = popen_match.group(1)
                    cmd_parts = command.strip().split()
                    
                    if not cmd_parts:
                        return jsonify({'error': 'Invalid command'}), 403
                    
                    allowed_commands = ['cat', 'ls', 'id', 'pwd', 'locate', 'find']
                    first_cmd = cmd_parts[0]
                    
                    if first_cmd not in allowed_commands:
                        return jsonify({'error': 'Command not permitted in this environment'}), 403
                    
                    try:
                        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=10)
                        output = result.stdout + result.stderr
                        return jsonify({'result': output if output else 'Command executed successfully'})
                    except subprocess.TimeoutExpired:
                        return jsonify({'error': 'Operation timed out'}), 400
                    except Exception as e:
                        return jsonify({'error': 'Execution failed'}), 400
                else:
                    return jsonify({'error': 'Invalid syntax'}), 403
            else:
                return jsonify({'error': 'This console has limited functionality'}), 403
                
        except Exception as e:
            return jsonify({'error': 'System error occurred'}), 500
    
    return render_template('console.html')

@app.route('/secret-console/logout')
def console_logout():
    session.pop('console_access', None)
    return redirect('/secret-console')
    
@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(403)
def forbidden_error(error):
    return render_template('403.html'), 403

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500


if __name__ == '__main__':
    app.run(debug=False, host="0.0.0.0", port=1337)