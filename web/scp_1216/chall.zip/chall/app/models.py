import enum


class ThreatLevel(enum.Enum):
    LOW = "Low"
    MODERATE = "Moderate"
    HIGH = "High"
    CRITICAL = "Critical"
    UNKNOWN = "Unknown"

def create_models(db):
    """Create model classes with the given db instance"""
    
    class User(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        username = db.Column(db.String(80), unique=True, nullable=False)
        password = db.Column(db.String(120), nullable=False)
        is_admin = db.Column(db.Boolean, default=False)

        def __repr__(self):
            return f'<User {self.username}>'
    
    class SCP(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(120), nullable=False)
        description = db.Column(db.Text, nullable=True)
        containment = db.Column(db.Text, nullable=True)
        threat_level = db.Column(db.Enum(ThreatLevel), nullable=True)

        def __repr__(self):
            return f'<SCP {self.name}>'
        
        def __init__(self, name, description, containment, threat_level, image_url=None):
            self.name = name
            self.description = description
            self.containment = containment
            self.threat_level = threat_level
    
    return User, SCP