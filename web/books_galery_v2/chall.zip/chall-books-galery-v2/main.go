package main

import (
	"books-galery-v2/database"
	"books-galery-v2/routes"
	"log"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
)

func main() {
	
	err := godotenv.Load()
    if err != nil {
        log.Println("Warning: Error loading .env file")
    }

	db := database.InitDatabase()

	router := gin.Default()

	router.Static("/images", "./images")

	routes.MapRouter(router, db)

	if err := router.Run(":8080"); err != nil {
		log.Fatalf("Failed to run server: %v", err)
	}
}
