package controllers

import (
	"books-galery-v2/lib"
	"database/sql"
	"html/template"
	"net/http"
	"path/filepath"
	"strings"

	"github.com/gin-gonic/gin"
)

type Author struct {
    AuthorID     int
    Name         string
    BirthCountry string
    BirthCity    string
    BirthDate    string
}

func ShowAuthors(db *sql.DB) gin.HandlerFunc {
    return func(c *gin.Context) {

        queryParams := c.Request.URL.Query()["query"]
        
        var searchQuery string
        if len(queryParams) > 0 {
            if len(queryParams) == 1 {
                searchQuery = "A"
            } else {
				var sanitizedParams []string
				for _, param := range queryParams {
					sanitized := lib.SanitizeData(param)
					sanitizedParams = append(sanitizedParams, sanitized)

				}
                searchQuery = strings.Join(sanitizedParams, "")
            }
        }

        var rows *sql.Rows
        var err error

        if searchQuery != "" {
            query := `
                SELECT author_id, name, birth_country, birth_city, birth_date 
                FROM authors 
                WHERE name LIKE '%` + searchQuery + `%' OR birth_country LIKE '%` + searchQuery + `%' OR birth_city LIKE '%` + searchQuery + `%'`
			

            rows, err = db.Query(query)
        } else {
            query := `SELECT author_id, name, birth_country, birth_city, birth_date FROM authors`
            rows, err = db.Query(query)
        }

        if err != nil {
            c.String(http.StatusInternalServerError, err.Error())
            return
        }
        defer rows.Close()

        var authors []Author
        for rows.Next() {
            var author Author
            err = rows.Scan(&author.AuthorID, &author.Name, &author.BirthCountry, &author.BirthCity, &author.BirthDate)
            if err != nil {
                c.String(http.StatusInternalServerError, err.Error())
                return
            }
            authors = append(authors, author)
        }

        if err := rows.Err(); err != nil {
            c.String(http.StatusInternalServerError, err.Error())
            return
        }

        fp := filepath.Join("views", "author-page.html")
        tmpl, err := template.ParseFiles(fp)

        if err != nil {
            c.String(http.StatusInternalServerError, err.Error())
            return
        }

        data := gin.H{
            "Authors":     authors,
            "SearchQuery": c.Query("query"),
        }

        err = tmpl.Execute(c.Writer, data)
        if err != nil {
            c.String(http.StatusInternalServerError, err.Error())
        }
    }
}