package controllers

import (
	"books-galery-v2/lib"
	"database/sql"
	"html/template"
	"net/http"
	"path/filepath"

	"github.com/gin-gonic/gin"
)

type Book struct {
	BookID    int
	GenreName string 
	Title     string
	Author    string
	Pages     int
	Synopsis  string
	ImgPath   string
}

type Comment struct {
	CommentID int
	Name string
	Comment string
}

func ShowBooks(db *sql.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		searchQuery := c.Query("query")
		searchQuery = lib.SanitizeData(searchQuery)
		
		var rows *sql.Rows
		var err error

		if searchQuery != "" {
			query := `
                SELECT b.book_id, b.title, b.author, b.img_path 
                FROM books b 
                JOIN genres g ON b.genre_id = g.genre_id 
                WHERE b.title LIKE ? OR b.author LIKE ?`
            
            searchParam := "%" + searchQuery + "%"
            rows, err = db.Query(query, searchParam, searchParam)
		} else {
			query := `SELECT b.book_id, b.title, b.author, b.img_path 
			          FROM books b 
			          JOIN genres g ON b.genre_id = g.genre_id`
			rows, err = db.Query(query)
		}

		if err != nil {
			c.String(http.StatusInternalServerError, err.Error())
			return
		}
		defer rows.Close()

		var books []Book
		for rows.Next() {
			var book Book
			err = rows.Scan(&book.BookID, &book.Title, &book.Author, &book.ImgPath)
			if err != nil {
				c.String(http.StatusInternalServerError, err.Error())
				return
			}
			books = append(books, book)
		}

		if err := rows.Err(); err != nil {
			c.String(http.StatusInternalServerError, err.Error())
			return
		}

		fp := filepath.Join("views", "index.html")
		tmpl, err := template.ParseFiles(fp)

		if err != nil {
			c.String(http.StatusInternalServerError, err.Error())
			return
		}

		data := gin.H{
			"Books": books,
		}

		err = tmpl.Execute(c.Writer, data)
		if err != nil {
			c.String(http.StatusInternalServerError, err.Error())
		}
	}
}


func ShowDetail(db *sql.DB) gin.HandlerFunc {
	return func(c *gin.Context) {
		bookID := c.Param("book_id")

		bookQuery := `SELECT b.book_id, g.genre_name, b.title, b.author, b.pages, b.synopsis, b.img_path
            FROM books b
            JOIN genres g ON b.genre_id = g.genre_id
            WHERE b.book_id = ?`

		var bookDetail Book
		err := db.QueryRow(bookQuery, bookID).Scan(&bookDetail.BookID, &bookDetail.GenreName, &bookDetail.Title, &bookDetail.Author, &bookDetail.Pages, &bookDetail.Synopsis, &bookDetail.ImgPath)
		if err != nil {
			if err == sql.ErrNoRows {
				c.String(http.StatusNotFound, "Book not found")
			} else {
				c.String(http.StatusInternalServerError, "Error retrieving book details: "+err.Error())
			}
			return
		}

		commentsQuery := `SELECT u.name, c.comment 
            FROM comments c
            LEFT JOIN users u ON c.user_id = u.user_id
            WHERE c.book_id = ?`

		rows, err := db.Query(commentsQuery, bookID)
		if err != nil {
			c.String(http.StatusInternalServerError, "Error retrieving comments: "+err.Error())
			return
		}
		defer rows.Close()

		var comments []Comment
		for rows.Next() {
			var comment Comment
			err := rows.Scan(&comment.Name, &comment.Comment)
			if err != nil {
				c.String(http.StatusInternalServerError, "Error scanning comments: "+err.Error())
				return
			}

			if comment.Name != "" && comment.Comment != "" {
				comments = append(comments, comment)
			}
		}

		fp := filepath.Join("views", "detail-book.html")
		tmpl, err := template.ParseFiles(fp)
		if err != nil {
			c.String(http.StatusInternalServerError, "Error loading template: "+err.Error())
			return
		}

		data := gin.H{
			"DetailBook": bookDetail,
			"Comments":   comments,  
		}

		err = tmpl.Execute(c.Writer, data)
		if err != nil {
			c.String(http.StatusInternalServerError, "Error rendering template: "+err.Error())
		}
	}
}





