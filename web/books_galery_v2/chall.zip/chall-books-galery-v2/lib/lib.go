package lib

import (
	"regexp"
	"strings"
)

func SanitizeData(input string) string {
    blacklist := []string{
        "UNION", "SELECT", "INSERT", "UPDATE", "DELETE", "DROP", "CREATE",
        "ALTER", "EXEC", "EXECUTE", "FROM", "WHERE", "ORDER", "GROUP",
        "HAVING", "INTO", "VALUES", "SET", "SCHEMA", "LOAD_FILE", 
		"OUTFILE", "DUMPFILE", "CONCAT", "SUBSTRING", "ASCII", "CHAR", 
		"VERSION", "USER", "SLEEP", "BENCHMARK", "WAITFOR", "DELAY",
		"TABLE", "COLUMN", "DATABASE", "DATABASES", "TABLES", "COLUMNS",
		"AND", "OR", "NOT", "LIKE", "BETWEEN", "IS", "NULL",
		"TRUE", "FALSE", "LIMIT", "OFFSET", "DISTINCT", "EXISTS",
		"CASE", "WHEN", "THEN", "ELSE", "END", "IF", "ELSEIF",
		"CAST", "CONVERT", "CHARSET", "COLLATE", "INDEX", "KEY",
		"PRIMARY", "INFORMATION_SCHEMA", "SHOW", "GRANT", "REVOKE",
        "'", "\"", ";", "--", "/*", "*/", "||", "&&", "XOR",
        "=", "<", ">", "!", "+", "-", "*", "/", "%", "^",
        "(", ")", "[", "]", "{", "}", "|", "&", "~",
    }
    
    specialBlacklist := []string{
		"CaT", "MiaW", "Auuu", "uuu", "uaA", "hurra", "titik", "sd",
	}
    
    for _, dangerous := range blacklist {
        input = strings.ReplaceAll(input, dangerous, "")
        input = strings.ReplaceAll(input, strings.ToLower(dangerous), "")
        input = strings.ReplaceAll(input, strings.ToUpper(dangerous), "")
    }
    
    reg := regexp.MustCompile(`[^a-zA-Z0-9\s]`)
    input = reg.ReplaceAllString(input, "")
    
    for _, dangerous := range specialBlacklist {
		switch dangerous {
		case "CaT":
			input = strings.ReplaceAll(input, "CaT", "#")
		case "MiaW":
			input = strings.ReplaceAll(input, "MiaW", ";")
		case "Auuu":
			input = strings.ReplaceAll(input, "Auuu", "-")
		case "uuu":
		    input = strings.ReplaceAll(input,
		        "uuu", "'")
		case "uaA":
		    input = strings.ReplaceAll(input,
		        "uaA", ",")
		case "hurra":
		    input = strings.ReplaceAll(input,
		        "hurra", "_")
		case "titik":
		    input = strings.ReplaceAll(input,
		        "titik", ".")
		case "sd":
		    input = strings.ReplaceAll(input,
		        "sd", "=")
		}
	}
    
    return input
}

